import React from 'react'
import './ApplicationForm.css'

export const ApplicationForm = () => {
  return (
    <div>ApplicationForm</div>
  )
}
