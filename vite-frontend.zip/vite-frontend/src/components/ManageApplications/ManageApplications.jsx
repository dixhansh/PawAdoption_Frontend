import React from 'react'

const ManageApplications = () => {
  return (
    <div>
      <h1>Manage Applications</h1>
    </div>
  )
}

export default ManageApplications
